# Lab 1 Report

## Objective
The objective was to understand Java inheritance and to use Junit 4 for unit testing.

## Design and Architecture
There are two interfaces. GasolineInterface and ElectricInterface. GasolineInterface handles gas calculations while ElectricInterface handles electric calculations. HybridVehicle implements both interfaces. CarRunner is the main class that prints out the gas MPG, electric MPGe, and the average for hybrid.

## Implementation Details
- calcGasMPG() divides miles by gallons
- calcMPGe() converts electric miles/kWh into an MPG-equivalent number
- calcAverageHybridMPG() averages the gas MPG and the electric MPGe.

## Test Strategy
JUnit 4 was used for testing. I used @Before and @Test for the test cases. There are 15 tests covering gas, electric, and hybrid calculations.

The test covered:
- Calculations for gas MPG and electric MPGe
- Edge case for gallons or kWh is 0
- Edge case for miles is 0
- Default and custom cost values for gas and electric
- Hybrid average calculation for both normal use and when both gas and electric values are 0
- Hybrid average calculation when only the gas side is set and electric is left at 0

## Conclusion
The lab was helpful in understanding interfaces in java. I also learned the way unit tests are implemented in a java program which can be sightly similar to how python implements unittest for testing but with different syntax.

## AI Usage
The AI I used for this lab was Claude. The main usage was for generating unit tests for the lab. I decided to use AI to fill in the little understanding I have in creating tests in java. 

## AI Prompt
I have a HybridVehicle class in package c that implements a GasolineInterface and ElectricInterface. It has methods calcGasMPG(), calcMPGe(), and calcAverageHybridMPG(), plus setters setMilesfromGas, setGallonsfromGas, setElectricMiles, setTotalkWh, and getter/setters for costPerGallon (default 3.50) and costPerkWh (default 0.24). calcGasMPG() returns 0 if gallons is 0, and calcMPGe() returns 0 if kWh is 0 (using 33.7 kWh per gallon for the conversion). Write a JUnit 4 test class TestMeTests in package u that uses @Before to instantiate the car and @Test methods covering: normal gas MPG, gas MPG with decimal values, gas MPG when gallons is 0, gas MPG when miles is 0, default and custom cost per gallon, normal MPGe, MPGe with decimal values, MPGe when kWh is 0, MPGe when miles is 0, default and custom cost per kWh, hybrid average MPG in normal use, hybrid average when both gas and electric are 0, and hybrid average when only the gas side is set.

## AI Response
```bash
package u;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import c.HybridVehicle;

public class TestMeTests {
    HybridVehicle car;

    @Before
    public void setUp() {
        car = new HybridVehicle();
    }

    // ---------- Gas Tests ----------

    @Test
    public void testGasMPG() {
        car.setMilesfromGas(120);
        car.setGallonsfromGas(6);

        double result = car.calcGasMPG();
        assertEquals(20.0, result, 0.01);
    }

    @Test
    public void testGasMPGWithDecimals() {
        car.setMilesfromGas(100);
        car.setGallonsfromGas(3.5);

        double result = car.calcGasMPG();
        assertEquals(28.57, result, 0.01);
    }

    @Test
    public void testGasMPGZeroGallons() {
        car.setMilesfromGas(50);
        car.setGallonsfromGas(0);

        double result = car.calcGasMPG();
        assertEquals(0.0, result, 0.01);
    }

    @Test
    public void testGasMPGZeroMiles() {
        car.setMilesfromGas(0);
        car.setGallonsfromGas(10);

        double result = car.calcGasMPG();
        assertEquals(0.0, result, 0.01);
    }

    @Test
    public void testDefaultCostPerGallon() {
        assertEquals(3.50, car.getCostPerGallon(), 0.01);
    }

    @Test
    public void testCustomCostPerGallon() {
        car.setCostPerGallon(4.25);
        assertEquals(4.25, car.getCostPerGallon(), 0.01);
    }

    // ---------- Electric Tests ----------

    @Test
    public void testMPGe() {
        car.setElectricMiles(300);
        car.setTotalkWh(70);

        double result = car.calcMPGe();
        assertEquals(144.43, result, 0.01);
    }

    @Test
    public void testMPGeWithDecimals() {
        car.setElectricMiles(150);
        car.setTotalkWh(45.5);

        double result = car.calcMPGe();
        assertEquals(111.10, result, 0.01);
    }

    @Test
    public void testMPGeZeroKWh() {
        car.setElectricMiles(100);
        car.setTotalkWh(0);

        double result = car.calcMPGe();
        assertEquals(0.0, result, 0.01);
    }

    @Test
    public void testMPGeZeroMiles() {
        car.setElectricMiles(0);
        car.setTotalkWh(70);

        double result = car.calcMPGe();
        assertEquals(0.0, result, 0.01);
    }

    @Test
    public void testDefaultCostPerKWh() {
        assertEquals(0.24, car.getCostPerkWh(), 0.01);
    }

    @Test
    public void testCustomCostPerKWh() {
        car.setCostPerkWh(0.30);
        assertEquals(0.30, car.getCostPerkWh(), 0.01);
    }

    // ---------- Hybrid Tests ----------

    @Test
    public void testHybridAverageMPG() {
        car.setMilesfromGas(120);
        car.setGallonsfromGas(6);
        car.setElectricMiles(300);
        car.setTotalkWh(70);

        double result = car.calcAverageHybridMPG();
        // (20.0 + 144.43) / 2 = 82.21
        assertEquals(82.21, result, 0.01);
    }

    @Test
    public void testHybridAverageMPGBothZero() {
        car.setMilesfromGas(0);
        car.setGallonsfromGas(0);
        car.setElectricMiles(0);
        car.setTotalkWh(0);

        double result = car.calcAverageHybridMPG();
        assertEquals(0.0, result, 0.01);
    }

    @Test
    public void testHybridAverageMPGOnlyGasSet() {
        car.setMilesfromGas(100);
        car.setGallonsfromGas(5);
        // electric fields left at 0 -> calcMPGe() returns 0

        double result = car.calcAverageHybridMPG();
        // (20.0 + 0.0) / 2 = 10.0
        assertEquals(10.0, result, 0.01);
    }
}
```