# Lab 1 - Hybrid Vehicle

## Overview
The java program has two interfaces which are GasolineInterface and ElectricInterface, a HybridVehicle class that implements both, and a CarRunner class that uses sample calculations from the assignment intructions.

## Preparation
In the folder above src (your code space)
```bash
curl -O https://repo1.maven.org/maven2/junit/junit/4.13.2/junit-4.13.2.jar
```
```bash
curl -O https://repo1.maven.org/maven2/org/hamcrest/hamcrest-
core/1.3/hamcrest-core-1.3.jar
```

## Folder Structure
Lab-1/
|-- c/ (GasolineInterface, ElectricInterface, HybridVehicle, CarRunner)
|-- u/ (TestMeTests)
|--junit-4.13.2.jar
|--hamcrest-core-1.3.jar

## How to Compile
This will complie all the java files
```bash
javac -cp junit-4.13.2.jar c/GasolineInterface.java c/ElectricInterface.java c/HybridVehicle.java c/CarRunner.java u/TestMeTests.java
```

## How to Run
This runs CarRunner.java
```bash
java -cp . c.CarRunner
```
This runs TestMeTests.java
```bash
java -cp "junit-4.13.2.jar:hamcrest-core-1.3.jar:." org.junit.runner.JUnitCore u.TestMeTests
```

## Car Runner Expected Output:
Fully Gas Mode

MPG = 20.0

Cost = $21.0

Fully Electric Mode

MPGe = 144.42857142857144

Cost = $16.8

Hybrid Mode

Average MPG = 82.21428571428572

## TestMeTests Expected Output:
JUnit version 4.13.2

....kWh = 0, returning 0 MPGe

.kWh = 0, returning 0 MPGe

....Gallons = 0, returning 0 MPG

kWh = 0, returning 0 MPGe

......Gallons = 0, returning 0 MPG

Time: 0.012

OK (15 tests)