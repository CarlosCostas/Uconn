package u;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import c.HybridVehicle;

public class TestMeTests {
    HybridVehicle car;

    @Before
    public void setUp() {
        car = new HybridVehicle();
    }

    // ---------- Gas Tests ----------

    @Test
    public void testGasMPG() {
        car.setMilesfromGas(120);
        car.setGallonsfromGas(6);

        double result = car.calcGasMPG();
        assertEquals(20.0, result, 0.01);
    }

    @Test
    public void testGasMPGWithDecimals() {
        car.setMilesfromGas(100);
        car.setGallonsfromGas(3.5);

        double result = car.calcGasMPG();
        assertEquals(28.57, result, 0.01);
    }

    @Test
    public void testGasMPGZeroGallons() {
        car.setMilesfromGas(50);
        car.setGallonsfromGas(0);

        double result = car.calcGasMPG();
        assertEquals(0.0, result, 0.01);
    }

    @Test
    public void testGasMPGZeroMiles() {
        car.setMilesfromGas(0);
        car.setGallonsfromGas(10);

        double result = car.calcGasMPG();
        assertEquals(0.0, result, 0.01);
    }

    @Test
    public void testDefaultCostPerGallon() {
        assertEquals(3.50, car.getCostPerGallon(), 0.01);
    }

    @Test
    public void testCustomCostPerGallon() {
        car.setCostPerGallon(4.25);
        assertEquals(4.25, car.getCostPerGallon(), 0.01);
    }

    // ---------- Electric Tests ----------

    @Test
    public void testMPGe() {
        car.setElectricMiles(300);
        car.setTotalkWh(70);

        double result = car.calcMPGe();
        assertEquals(144.43, result, 0.01);
    }

    @Test
    public void testMPGeWithDecimals() {
        car.setElectricMiles(150);
        car.setTotalkWh(45.5);

        double result = car.calcMPGe();
        assertEquals(111.10, result, 0.01);
    }

    @Test
    public void testMPGeZeroKWh() {
        car.setElectricMiles(100);
        car.setTotalkWh(0);

        double result = car.calcMPGe();
        assertEquals(0.0, result, 0.01);
    }

    @Test
    public void testMPGeZeroMiles() {
        car.setElectricMiles(0);
        car.setTotalkWh(70);

        double result = car.calcMPGe();
        assertEquals(0.0, result, 0.01);
    }

    @Test
    public void testDefaultCostPerKWh() {
        assertEquals(0.24, car.getCostPerkWh(), 0.01);
    }

    @Test
    public void testCustomCostPerKWh() {
        car.setCostPerkWh(0.30);
        assertEquals(0.30, car.getCostPerkWh(), 0.01);
    }

    // ---------- Hybrid Tests ----------

    @Test
    public void testHybridAverageMPG() {
        car.setMilesfromGas(120);
        car.setGallonsfromGas(6);
        car.setElectricMiles(300);
        car.setTotalkWh(70);

        double result = car.calcAverageHybridMPG();
        // (20.0 + 144.43) / 2 = 82.21
        assertEquals(82.21, result, 0.01);
    }

    @Test
    public void testHybridAverageMPGBothZero() {
        car.setMilesfromGas(0);
        car.setGallonsfromGas(0);
        car.setElectricMiles(0);
        car.setTotalkWh(0);

        double result = car.calcAverageHybridMPG();
        assertEquals(0.0, result, 0.01);
    }

    @Test
    public void testHybridAverageMPGOnlyGasSet() {
        car.setMilesfromGas(100);
        car.setGallonsfromGas(5);
        // electric fields left at 0 -> calcMPGe() returns 0

        double result = car.calcAverageHybridMPG();
        // (20.0 + 0.0) / 2 = 10.0
        assertEquals(10.0, result, 0.01);
    }
}