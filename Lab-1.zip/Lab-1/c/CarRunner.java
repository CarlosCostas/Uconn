package c;

public class CarRunner {
    
    public static void main(String[] args) {
        
        HybridVehicle car = new HybridVehicle();
        
        // Fully gas
        car.setMilesfromGas(120);
        car.setGallonsfromGas(6);

        double gasMPG = car.calcGasMPG();
        double gasCost = car.getCostPerGallon() * 6;

        System.out.println("Fully Gas Mode");
        System.out.println("MPG = " + gasMPG);
        System.out.println("Cost = $" + gasCost);

        // Fully electric
        car.setElectricMiles(300);
        car.setTotalkWh(70);

        double mpge = car.calcMPGe();
        double electricCost = car.getCostPerkWh() * 70;

        System.out.println("Fully Electric Mode");
        System.out.println("MPGe = " + mpge);
        System.out.println("Cost = $" + electricCost);

        // Hybrid mode
        double avgMPG = car.calcAverageHybridMPG();

        System.out.println("Hybrid Mode");
        System.out.println("Average MPG = " + avgMPG);

    }
}