package c;

public class HybridVehicle implements GasolineInterface, ElectricInterface {
   
    double kWhPerGallon = 33.7;

    double milesFromGas;
    double gallonsFromGas;
    double costPerGallon = 3.50;

    double electricMiles;
    double totalkWh;
    double costPerkWh = 0.24;

    // Gas mode

    public double calcGasMPG() {
        if (gallonsFromGas == 0) {
            System.out.println("Gallons = 0, returning 0 MPG");
            return 0;
        }
        double mpg = milesFromGas / gallonsFromGas;
        return mpg;
    }
    
    public void setMilesfromGas(double miles) {
        milesFromGas = miles;
    }
    
    public void setGallonsfromGas(double gallons) {
        gallonsFromGas = gallons;
    }

    public double getCostPerGallon() {
        return costPerGallon;
    }

    public void setCostPerGallon(double cost) {
        costPerGallon = cost;
    }

    // Electric mode

    public double calcMPGe() {
        if (totalkWh == 0) {
            System.out.println("kWh = 0, returning 0 MPGe");
            return 0;
        }
        double mpge = (electricMiles / totalkWh) * kWhPerGallon;
        return mpge;
    }

    public void setElectricMiles(double miles) {
        electricMiles = miles;
    }

    public void setTotalkWh(double kwh) {
        totalkWh = kwh;
    }
    
    public double getCostPerkWh() {
        return costPerkWh;
    }

    public void setCostPerkWh(double cost) {
        costPerkWh = cost;
    }

    // Hybrid mode

    public double calcAverageHybridMPG() {
        double gasMPG = calcGasMPG();
        double electricMPGe = calcMPGe();
        double average = (gasMPG + electricMPGe) / 2;
        return average;
    }
}